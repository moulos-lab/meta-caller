#!/usr/bin/env python3

import sys
import os
import subprocess
from multiprocessing import Pool
import argparse
from pathlib import Path

parser = argparse.ArgumentParser(description="Simulated ChIPseq data for treatment and control using R package \"ChIPsim\"", prog="ChIPsim")

required_p = parser.add_argument_group('required arguments')
required_p.add_argument("-d", "--dir", help = "directory with chromosome .fa files", type = Path, required = True)
required_p.add_argument("-s", help = "seed number for the simulation", type = int, required = True)
parser.add_argument("-n", help ="number of cores", type = int, default = 1)

if len(sys.argv) == 1:
    parser.print_help(file = sys.stderr)
    sys.exit()

args = parser.parse_args()

try:
    directory=args.dir
    print(directory)
    os.chdir(directory)
    fafiles = []
    for file in os.listdir(directory):
        if file.endswith(".fa"):
            fafiles.append(file)
    num_chromosomes = len(fafiles)
    if num_chromosomes !=0:
        print(f"There are {num_chromosomes} chromosomes.")
    else:
        print("No chromosome files in this directory. Files must have .fa  extension.")
        sys.exit()

    try:
        path = f'{directory}/FeatFiles'
        os.mkdir(path)
    except:
        print("FeatFiles directory exists.")


except:
    print('Please pass directory.')
    sys.exit()

num_processes = args.n
seed = args.s

chr_dir = {}
for chrom in enumerate(fafiles,1):
    chr_dir[chrom[1]] = chrom[0]

def calculate(func, args):
    result = func(*args)
    return result

def chipsim1(fafile, chr, seed):
    seed = chr_dir[f'{fafile}'] * seed
    return subprocess.run(['Rscript', f'{directory}/rscripts/chipsim1.r', f'{fafile}', f'{chr}', f'{seed}'])

def chipsim2(fafile, chr, seed):
    seed = chr_dir[f'{fafile}'] * seed
    return subprocess.run(['Rscript', f'{directory}/rscripts/chipsim2.r', f'{fafile}', f'{chr}', f'{seed}'])

def chipsim3(fafile, chr, seed):
    seed = chr_dir[f'{fafile}'] * seed
    return subprocess.run(['Rscript', f'{directory}/rscripts/chipsim3.r', f'{fafile}', f'{chr}', f'{seed}'])

def chipsim4(fafile, chr, seed):
    seed = chr_dir[f'{fafile}'] * seed
    return subprocess.run(['Rscript', f'{directory}/rscripts/chipsim4.r', f'{fafile}', f'{chr}', f'{seed}'])

def chipsim5(fafile, chr, seed):
    seed = chr_dir[f'{fafile}'] * seed
    return subprocess.run(['Rscript', f'{directory}/rscripts/chipsim5.r', f'{fafile}', f'{chr}', f'{seed}'])


def test():
    with Pool(processes=num_processes) as pool:
        TASKS = [(chipsim1, (file, file.split(".")[0], seed + 1)) for file in fafiles]+ \
                [(chipsim2, (file, file.split(".")[0], seed + 2)) for file in fafiles] + \
                [(chipsim3, (file, file.split(".")[0], seed + 3)) for file in fafiles] + \
                [(chipsim4, (file, file.split(".")[0], seed + 4)) for file in fafiles] + \
                [(chipsim5, (file, file.split(".")[0], seed + 5)) for file in fafiles]
        results = [pool.apply_async(calculate, t) for t in TASKS]
        for r in results:
            r.get()
                                                                                                                                                                                                                                                                                                    
if __name__ == '__main__':
    test()
