library(ChIPsim)
rm(list=ls())

args <- commandArgs(trailingOnly = TRUE)

Fast_FileName <- args[1]
ExpNo <- args[2]
cwd <- getwd()
Feat_FileName <- paste(cwd, "/", "FeatFiles", "/", "Feat", sep ="")
seed_num <- as.numeric(args[3])


shape1 <- 1
scale1 <- 20
enrichment1 <- 20
r1 <- 2
BindLength <- 50
MinLength <- 150
MaxLength <- 250
MeanLength <- 200
BindingProb <- 0.002
BackgroundProb <- 1-BindingProb
BackgroundFeatureLength <- 1000
seed2 <- seed_num

#length of reads
LengthReads <- 50

#read genome
genome <- readDNAStringSet(Fast_FileName)
chrLen <- width(genome)
chromosomes <- genome[[1]]

#Number of reads
Nreads <- 0.15*(chrLen/LengthReads)

#randomly generate quality of reads
randomQuality <- function(read, ...){
	paste(sample(unlist(strsplit(rawToChar(as.raw(74:104)),"")), length(read), replace = TRUE), collapse="")
  }

defaultErrorProb1 <- function () {
	prob <- list(A = c(1,0,0,0), C = c(0,1,0,0), G = c(0,0,1,0), T = c(0,0,0,1))
  prob <- lapply(prob, "names<-", c("A", "C", "G", "T"))
	prob
	}

readError1 <- function (read, qual, alphabet = c("A", "C", "G", "T"), prob = defaultErrorProb1(), ...) {
	read <- gsub(paste("[^", paste(alphabet, collapse = "", sep = ""), "]", sep = ""), alphabet[1], read)
  errorPos <- rep(1, length(qual)) < qual
	if(any(errorPos)) {
		for (i in which(errorPos)) {
			transProb <- prob[[substr(read, i, i)]]
		  substr(read, i, i) <- sample(names(transProb),1, prob = transProb)
									             }
		                }
	read
	}


pos2fastq1 <- function (readPos, names, quality, sequence, qualityFun, errorFun, readLen = LengthReads , file, qualityType = c("Illumina", "Sanger", "Solexa"), ...)
{
	if (file != "" && !is(file, "connection") && !file.exists(file)) file <- file(file, open = "w", blocking = FALSE)
	replaceProb <- if (is.null(list(...)$prob))
	defaultErrorProb1()
	else match.fun(list(...)$prob)
	qualityFun <- match.fun(qualityFun)
	errorFun <- match.fun(errorFun)
	for (i in 1:2) {
		for (j in 1:length(readPos[[i]])) {
			readSeq <- readSequence(readPos[[i]][j], sequence, strand = ifelse(i == 1, 1, -1), readLen = readLen)
			readQual <- qualityFun(readSeq, quality, ...)
			readSeq <- errorFun(readSeq, decodeQuality(readQual, type = qualityType), prob = replaceProb)
			writeFASTQ(as.character(readSeq), as.character(readQual), names[[i]][j], file = file, append = TRUE)
																			}
									}
	invisible(sum(sapply(readPos, length)))
	}

#transitions
transition <- list(Binding=c(Background=1), Background=c(Binding=BindingProb, Background=BackgroundProb))
transition <- lapply(transition, "class<-", "StateDistribution")

#initial
init <- c(Binding=0, Background=1)
class(init) <- "StateDistribution"

#backgroundEmission
backgroundFeature <- function(start, length=BackgroundFeatureLength, shape=shape1, scale=scale1){
	weight <- rgamma(1, shape=shape1, scale=scale1)
	params <- list(start = start, length = length, weight = weight)
	class(params) <- c("Background", "SimulatedFeature")
	params
	}

#bindingEmission
bindingFeature <- function(start, length=BindingFeatureLength, shape=shape1, scale=scale1, enrichment=enrichment1, r=r1){
	stopifnot(r > 1)
	avgWeight <- shape * scale * enrichment
	lowerBound <- ((r - 1) * avgWeight)
	weight <- actuar::rpareto1(1, r, lowerBound)
	params <- list(start = start, length = length, weight = weight)
	class(params) <- c("Binding", "SimulatedFeature")
	params
	}

#generator
generator <- list(Binding=bindingFeature, Background=backgroundFeature)

#featureDensity1
constRegion <- function(weight, length) rep(weight, length)

featureDensity.Binding <- function(feature, ...) constRegion(feature$weight, feature$length)
featureDensity.Background <- function(feature, ...) constRegion(feature$weight, feature$length)

#reconcileFeatures
reconcileFeatures.TFExperiment <- function(features, ...){
	bindIdx <- sapply(features, inherits, "Binding")
  if(any(bindIdx))
	bindLength <- features[[min(which(bindIdx))]]$length
	else bindLength <- 1
	lapply(features, function(f){
		if(inherits(f, "Background"))
		f$weight <- f$weight/bindLength
		f$overlap <- 0
		currentClass <- class(f)
		class(f) <- c(currentClass[-length(currentClass)], "ReconciledFeature", currentClass[length(currentClass)])
		f													}
			)
	}

#featureDensity2
featureDensity.Binding <- function(feature, ...) {
	featDens <- numeric(feature$length)
  featDens[floor(feature$length/2)] <- feature$weight
	featDens
	}

#fragmentLength
fragLength <- function(x, minLength, maxLength, meanLength, ...){
	sd <- (maxLength - minLength)/4
  prob <- dnorm(minLength:maxLength, mean = meanLength, sd = sd)
	prob <- prob/sum(prob)
	prob[x - minLength + 1]
	}

set.seed(seed2)

GenerateChipSeqFastqFiles <- function(ExpNo) {
	print("test 1")
	features <- placeFeatures(generator, transition, init, start = 0, length = chrLen, globals=list(shape=shape1, scale=scale1), experimentType="TFExperiment", lastFeat    = c(Binding = FALSE, Background = TRUE), control=list(Binding=list(length=BindLength)))

	BindingVec <- vector(mode="character")
	StartVec <- vector(mode="numeric")
	LengthVec <- vector(mode="numeric")
	WeightVec <- vector(mode="numeric")

	for(i in 1:length(features)) {
		BindingVec[i] <- class(features[[i]])[1]
		StartVec[i] <- features[[i]]$start
		LengthVec[i] <- features[[i]]$length
		WeightVec[i] <- features[[i]]$weight
		}

	FeaturesResult <- data.frame(cbind(Bind=BindingVec, Start=StartVec, Length=LengthVec, Weight=WeightVec))
	write.table(FeaturesResult, paste(Feat_FileName, enrichment1, ExpNo ,".txt",sep=""), sep="\t", row.names=FALSE)
	print("test 2")

	#create features for the input data
	features0 <- features
	bindIdx <- sapply(features, inherits, "Binding")
	BindIndices <- which(bindIdx)
	for(i in BindIndices) {
		class(features0[[i]]) <- class(features0[[i+1]])
		features0[[i]]$weight <- features0[[i+1]]$weight
											   }
	dens <- feat2dens(features, length = chrLen)
	dens0 <- feat2dens(features0, length = chrLen)
	print("test 3")

	readDens <- bindDens2readDens(dens, fragLength, bind = BindLength, minLength = MinLength, maxLength = MaxLength, meanLength = MeanLength)
	readDens0 <- bindDens2readDens(dens0, fragLength, bind = BindLength, minLength = MinLength, maxLength = MaxLength, meanLength = MeanLength)
	print("test 4")

	readLoc <- sampleReads(readDens, Nreads)
	readLoc0 <- sampleReads(readDens0, Nreads)
	print("test 5")

	names <- list(paste("read", 1:length(readLoc[[1]]), sep="_"), paste("read", (1+length(readLoc[[1]])):(Nreads), sep="_"))
	names0 <- list(paste("read", 1:length(readLoc0[[1]]), sep="_"), paste("read", (1+length(readLoc0[[1]])):(Nreads), sep="_"))
	print("test 6")

	pos2fastq1(readPos=readLoc, names = names, sequence=chromosomes, qualityFun=randomQuality, errorFun=readError1, readLen = LengthReads, file=paste( ExpNo, enrichment1, ".fastq",sep=""), qualityType = c("Illumina"))
	pos2fastq1(readPos=readLoc0, names = names0, sequence=chromosomes, qualityFun=randomQuality, errorFun=readError1, readLen = LengthReads, file=paste("control_", enrichment1, ExpNo,".fastq",sep=""), qualityType = c("Illumina"))
	print("Done")
	print(seed2)
	}

GenerateChipSeqFastqFiles(ExpNo)
#sessionInfo()
